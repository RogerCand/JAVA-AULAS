/**
 * 
 * @author 36129382023.2N
 *
 */
public class HelloWorld {
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		
		// Primeiro projeto
		System.out.println("Hello World");
	}

}
