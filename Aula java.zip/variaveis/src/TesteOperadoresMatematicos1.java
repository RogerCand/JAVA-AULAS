
public class TesteOperadoresMatematicos1 {

	public static void main(String[] args) {
		
		
		int a= 1;
//		a = a + 1;
		a += 1;
		
		int b = 2;
//		b = b - 1;
		b -= 1;
		
		int c = 5;
//		c = c * 2;
		c *= 2;
		
		int d = 30;
//		d = d / 2;
		d /= 2;
		
		int e = 10;
//		e = e % 2;
		e %= 2;
		
		System.out.println("a=" + a);
		System.out.println("b=" + b);
		System.out.println("c=" + c);
		System.out.println("d=" + d);
		System.out.println("e=" + e);

		// TODO Auto-generated method stub

	}

}
