
public class TesteAtribuicaoVariaveis2 {

	public static void main(String[] args) {
		// Variáveis
		
		boolean g = true;
		char c = '1';
		byte b = 0;
		short s = 0;
		int i = 0;
		long l = 0;
		float f = 0;
		double d = 0;
		
		// Atribuição de variáveis
		
		g = true;
		c = '1';
		b = 0;
		s = 0;
		i = 0;
		l = 0;
		f = 0;
		d = 0;
		
		// Exibição de variáveis
		
		System.out.println("g=" + g);
		System.out.println("c=" + c);
		System.out.println("b=" + b);
		System.out.println("s=" + s);
		System.out.println("i=" + i);
		System.out.println("l=" + l);
		System.out.println("f=" + f);
		System.out.println("d=" + d);
	
		
		
		

	}

}
